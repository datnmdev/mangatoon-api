CREATE DATABASE  IF NOT EXISTS `user_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `user_db`;
-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: 127.0.0.1    Database: user_db
-- ------------------------------------------------------
-- Server version	8.0.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status` int NOT NULL DEFAULT '0',
  `role` varchar(50) NOT NULL DEFAULT 'user',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userId` int NOT NULL,
  `provider` varchar(150) NOT NULL DEFAULT 'local',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userId_UNIQUE` (`userId`),
  CONSTRAINT `FK_user_account` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,1,'admin','2024-06-28 00:00:00',1,'local'),(2,0,'user','2024-06-28 00:00:00',2,'local'),(3,2,'user','2024-06-28 00:00:00',3,'local'),(4,3,'user','2024-06-29 04:50:53',4,'local'),(5,1,'user','2024-06-29 06:48:28',5,'google'),(6,1,'user','2024-06-29 06:48:58',6,'facebook'),(7,1,'user','2024-06-29 06:55:38',7,'google'),(8,0,'user','2024-06-29 08:27:54',8,'local'),(12,2,'user','2024-06-29 10:47:46',12,'google'),(13,1,'user','2024-06-29 11:50:20',13,'google'),(14,1,'user','2024-06-29 11:51:41',14,'google'),(15,0,'user','2024-07-21 12:42:16',15,'local'),(17,3,'user','2024-07-21 12:43:46',17,'local'),(18,0,'user','2024-07-21 12:46:21',18,'local'),(20,0,'user','2024-07-22 14:31:28',20,'local'),(22,0,'user','2024-07-22 14:32:37',22,'local'),(24,0,'user','2024-07-23 00:07:38',24,'local'),(26,0,'user','2024-07-23 00:07:41',26,'local'),(28,0,'user','2024-07-23 00:08:49',28,'local'),(29,0,'user','2024-07-23 00:08:49',29,'local'),(32,0,'user','2024-07-23 02:34:06',32,'local'),(33,0,'user','2024-07-23 02:34:06',33,'local'),(36,0,'user','2024-07-23 02:46:39',36,'local'),(37,0,'user','2024-07-23 02:46:39',37,'local'),(40,0,'user','2024-07-27 13:13:38',40,'local'),(42,0,'user','2024-07-27 13:13:38',42,'local'),(44,0,'user','2024-07-27 13:14:18',44,'local'),(46,0,'user','2024-07-27 13:14:18',46,'local'),(48,0,'user','2024-07-27 13:14:48',48,'local'),(50,0,'user','2024-07-27 13:14:48',50,'local'),(52,0,'user','2024-07-27 13:15:02',52,'local'),(54,0,'user','2024-07-27 13:15:02',54,'local');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailPasswordCredential`
--

DROP TABLE IF EXISTS `emailPasswordCredential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emailPasswordCredential` (
  `id` int NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  CONSTRAINT `FK_account_emailPasswordCredential` FOREIGN KEY (`id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailPasswordCredential`
--

LOCK TABLES `emailPasswordCredential` WRITE;
/*!40000 ALTER TABLE `emailPasswordCredential` DISABLE KEYS */;
INSERT INTO `emailPasswordCredential` VALUES (1,'datnm.ptit@gmail.com','$2b$10$7EEcw0OhBu5xCremyBl2l.ToF6PQ/cuFznPV8aW6bkiNqWlGNppaS'),(2,'n20dccn095@student.ptithcm.edu.vn','$2b$10$xOI.MKwyzp51DaNK/iY5ie09tFFXIwbRmZje4K/A1nS9hu/fCKnWa'),(3,'minhdat450500@gmail.com','$2b$10$LNtt1AqKQjQvQ2.FyUN9MeAgIaz8nHGRtQSq8IJ3e.lfH9LQ.ooIK'),(4,'datnm.study@gmail.com','$2b$10$F4mclYfeDtFz8LthjiQeUONCMLvrLU8JrwdlRVhoYBkLYp7NhYmy6'),(15,'n20dccn095@gmail.commm','$2b$10$Bjml9FZQ8bbf0T9JQCFeIeM9.8bG9PC4Y3CXcPhT3zNZ7QAW.C2JK'),(17,'n20dccn095@gmail.commmm','$2b$10$AvkEF6qEK1mqdhzzkxoPy.llVQKcsBMemSgEWa1Q35GhaNoSFqfLK'),(18,'n20dccn095@gmail.commmmm','$2b$10$xqLKWz7hFEpUcIFT3wDazOuqePuVGrX3DSxnwlZ05XoYMoyAkoi8G'),(20,'3a78c5301c275cc83fa6237621651dc0@example.com','$2b$10$rMfd0L.tCP.6KkvmPdKJEuo/RH27zNegaIeQzzqCJoRgVQgqIz.Mm'),(22,'dd5ef364d6c89dffcac357211f422820@example.com','$2b$10$fV9MRVUSTTxVCl87AmPsAOUkByfu0O16lTg3Fs0cxet3zfIUIdlve'),(24,'634f6db55f7294831506068163df0bf0@example.com','$2b$10$8J1cXE2EgCGdKDIpsWwAQOvkRNSLjLXunZjxx15oE5R/lnqQVCIMe'),(26,'67c1cb15578883895c7399a9d91650e9@example.com','$2b$10$CHe7W24kA6P341riDT2wtOOwElc.2w9q5q2FOA6VHFOXnFdKi5Yxa'),(28,'564c5d69d47c2aae0f62e9a270d55cd5@example.com','$2b$10$eNW6uRYJTcQsDKUFOysr6eXaFZqIJNEBXyba6PDXDG6uW08CbVQXW'),(29,'e99e01547c692fe3c9c2824690fb9839@example.com','$2b$10$n2Jw7/ReWVPJ8Jc9fKpWhOiefKZv6BqdF9rlaSkyDM4vg9BKfHDFW'),(32,'8f0f210c189d7f34ffe1823265ebcbe4@example.com','$2b$10$5UmFmimunvtpy7T.8FBpN.JooGiHBFiiEVfEvK1IX/k46.42Ewm7m'),(33,'c0c8ab156fdbfee618d2211edb799f30@example.com','$2b$10$PUQ1WT4kpIHJ8V8U5m9M8efKbPOOdjs8k7wr8f1DA81ktmsCPEqX2'),(36,'0c0d41313db8adce38953c9d04cd6e1a@example.com','$2b$10$Ow2nqlkLbxcRTqNKgaX10OqExNutlHw1pa9Dgxh0LufRR5.prFDSy'),(37,'779cefd31537614a59c492acf73c53a0@example.com','$2b$10$xTe5jnvODyyExSUothBy1eVGXmPwF6hIXO1/GShk4d84mxOsRAwby'),(40,'4eb57f3b7e74a67d70ed6ee2eda76419@example.com','$2b$10$OhQSv/sjB5hQ8N.TplrIM.6W2kK0ihLwnd65uqtKCuXL1UnYscham'),(42,'399688abfd820c2ef9372e4eea380c69@example.com','$2b$10$ZKdHukn6QO2W/YZUnYjrF.mSrHY/xPxdBKmaoJF8r0zrwRFY/ix4e'),(44,'3ca7d8c1c632531ee12126e269f2a1b7@example.com','$2b$10$lVBH2TsefKwpVa5BTmrhP.B5obfwZqPUwK.FVlB1it4jHsxRg6Nkq'),(46,'8c758697ae3ad461eb219d3669e17193@example.com','$2b$10$L4GnC9AJWKwL64YE1/h28uCsFeS1X8dyZX57w6jBhpsfMgBdi1owG'),(48,'a2bd4bea2a6768cdef6d6ab6e7e9a829@example.com','$2b$10$P.bVE6N2215UQU7QxSjqUerBKOoPXfCZU6SjP5NO9wovKh8TxfysC'),(50,'2675c85eda308baf48f0401b2041a37a@example.com','$2b$10$slIgrnDhRD1kkWJHXU.WGeB/BKJfEmAinquzOiPtYsDYReflw5X4O'),(52,'2e9da8a3fd5314e9d3264176e47b0844@example.com','$2b$10$XBihkMxh6pU/g4kyfNNXDOL0gzoHiTPZhGC0eZFOa.e1meH4Spdma'),(54,'e97b6ec68547932eeb8acea544323ee5@example.com','$2b$10$Iy9CmIZB68a2dOu1HcEBDe8rL8hscOCx31WzT5PwnoTLIipjjNDqC');
/*!40000 ALTER TABLE `emailPasswordCredential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facebookCredential`
--

DROP TABLE IF EXISTS `facebookCredential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facebookCredential` (
  `id` int NOT NULL,
  `uid` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_UNIQUE` (`uid`),
  CONSTRAINT `FK_account_facebookCredential` FOREIGN KEY (`id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facebookCredential`
--

LOCK TABLES `facebookCredential` WRITE;
/*!40000 ALTER TABLE `facebookCredential` DISABLE KEYS */;
INSERT INTO `facebookCredential` VALUES (6,'IfetSi2n8OUGhwW0qRiicHimwDr2');
/*!40000 ALTER TABLE `facebookCredential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `googleCredential`
--

DROP TABLE IF EXISTS `googleCredential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `googleCredential` (
  `id` int NOT NULL,
  `uid` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_UNIQUE` (`uid`),
  CONSTRAINT `FK_account_googleCredential` FOREIGN KEY (`id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `googleCredential`
--

LOCK TABLES `googleCredential` WRITE;
/*!40000 ALTER TABLE `googleCredential` DISABLE KEYS */;
INSERT INTO `googleCredential` VALUES (13,'1GMbSQwO3dhcDYQceAlUEMn418o1'),(12,'ccMqwofIXybG8KWBt69nQlaU2eA2'),(14,'dH1IPQEzZWcPGPp6Q9wOKdnhM4C3'),(7,'HqYBFdVQziTjjZLXowdvai5LKuy1'),(5,'lO4aYbRMUxekAxI7ZfqTfox0EYS2');
/*!40000 ALTER TABLE `googleCredential` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `gender` int NOT NULL DEFAULT '0',
  `dob` date DEFAULT NULL,
  `avatarUrl` text,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `FTS_name_user` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Minh Đạt',0,'2002-06-17','avatars/97d0bd957b83f2c4bf09acb40c4ad826.jpeg'),(2,'Nguyễn Minh Đạt',0,'2002-06-17',NULL),(3,'Nguyễn Minh Đạt',0,'2002-06-17','avatars/b6f4f9e7ee5818832a005a5ea2954b37.jpeg'),(4,'Nguyễn Minh Đạt',0,'2002-06-17',NULL),(5,'Đạt Nguyễn Minh',0,'2024-06-17','avatars/894941d531aa22b970a55e0b3716a957.jpeg'),(6,'Nguyễn Minh Đạt',0,NULL,'avatars/5524891a99e949da62dafce8bcf84220.jpeg'),(7,'Đạt Nguyễn Minh',0,NULL,'avatars/26653035de8f4cc1068dda6716fa3c62.png'),(8,'Nguyen Minh Dat',0,'2002-06-17',NULL),(12,'D20CQCN02-N NGUYEN MINH DAT',0,NULL,'avatars/e5b158f5a1e61a8faff924daf09005cd.jpeg'),(13,'Đạt Nguyễn Minh',0,NULL,'https://lh3.googleusercontent.com/a/ACg8ocJSjbYbsrZKXUHbx4xB59jDabEheDnmLbvuGzhjcZTa6SfVQg=s96-c'),(14,'Đạt Nguyễn Minh',0,NULL,'https://lh3.googleusercontent.com/a/ACg8ocKn8Wa427Gquu-JGOzSZbIvEf9AOAtJl5HDFXr5IhwPYTqMWw=s96-c'),(15,'Nguyen Minh Dat',0,NULL,NULL),(17,'user-2fd1e60de2964fd1978c8306abfd4517',0,NULL,NULL),(18,'Nguyen Minh Dat',0,'2002-06-17',NULL),(20,'Nguyen Minh Dat',0,'2002-06-17',NULL),(22,'Nguyen Minh Dat',0,'2002-06-17',NULL),(24,'Nguyen Minh Dat',0,'2002-06-17',NULL),(26,'Nguyen Minh Dat',0,'2002-06-17',NULL),(28,'Nguyen Minh Dat',0,'2002-06-17',NULL),(29,'Nguyen Minh Dat',0,'2002-06-17',NULL),(32,'Nguyen Minh Dat',0,'2002-06-17',NULL),(33,'Nguyen Minh Dat',0,'2002-06-17',NULL),(36,'Nguyen Minh Dat',0,'2002-06-17',NULL),(37,'Nguyen Minh Dat',0,'2002-06-17',NULL),(40,'Nguyen Minh Dat',0,'2002-06-17',NULL),(42,'Nguyen Minh Dat',0,'2002-06-17',NULL),(44,'Nguyen Minh Dat',0,'2002-06-17',NULL),(46,'Nguyen Minh Dat',0,'2002-06-17',NULL),(48,'Nguyen Minh Dat',0,'2002-06-17',NULL),(50,'Nguyen Minh Dat',0,'2002-06-17',NULL),(52,'Nguyen Minh Dat',0,'2002-06-17',NULL),(54,'Nguyen Minh Dat',0,'2002-06-17',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'user_db'
--

--
-- Dumping routines for database 'user_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-29 23:31:26
